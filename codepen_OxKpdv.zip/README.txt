A Pen created at CodePen.io. You can find this one at https://codepen.io/aneofy04/pen/OxKpdv.

 